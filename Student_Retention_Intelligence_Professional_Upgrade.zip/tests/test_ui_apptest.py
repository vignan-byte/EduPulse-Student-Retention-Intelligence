"""Comprehensive headless AppTest suite for EduPulse v10.0 platform UI and navigation."""
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from src.registry import verified_load


@pytest.fixture(scope="module")
def app_path():
    return str(Path(__file__).resolve().parents[1] / "app.py")


def test_app_loads_cleanly(app_path):
    """Verify application boots with zero startup exceptions and displays master title."""
    app = AppTest.from_file(app_path, default_timeout=35).run()
    assert not app.exception
    assert any("Student Dropout" in t.value for t in app.title)


def test_app_historical_student_toggle(app_path):
    """Verify historical record #130 toggle executes real inference with zero errors."""
    app = AppTest.from_file(app_path, default_timeout=35).run()
    hist_box = next(c for c in app.checkbox if "Use one existing" in c.label)
    hist_box.check().run()
    assert not app.exception
    assert any("Estimated dropout" in m.label for m in app.metric)


def test_all_navigation_views_render(app_path):
    """Iterate through major navigation views and ensure zero unhandled exceptions."""
    app = AppTest.from_file(app_path, default_timeout=35).run()
    radio = app.sidebar.radio[0]
    
    views_to_test = [
        "📊 Overview",
        "🎯 Student Risk Intelligence",
        "📝 Student Assessment & Digital Twin",
        "🔬 Model Performance Lab",
        "🧠 Explainable AI",
        "🗺️ Cohort Intelligence & Risk Heatmap",
        "📈 Institutional Analytics",
        "🛡️ Model Reliability & Drift Monitor",
        "📜 Methodology & Governance",
        "🎓 Faculty Demo Mode"
    ]
    
    for view in views_to_test:
        if view in radio.options:
            radio.set_value(view).run()
            assert not app.exception, f"Exception occurred while rendering view: {view}"
