# EduPulse v10.0 — Student Retention Intelligence Platform

**Course:** INT395 — Supervised Learning  
**Group:** 12 (Kabya Varun • Duggisetty Vasavi Vignan • Shivraj Singh)  
**Academic Year:** 2026–2027  

EduPulse is an enterprise-grade, explainable supervised-learning decision-support system built on the published UCI 697 dataset (4,424 students, 36 predictors). Designed for live academic defense and real-world higher-education advising, it combines multi-model ensembling, probability calibration, counterfactual algorithmic recourse, SHAP/LIME attribution, a Student Digital Twin & What-If Studio, an interactive confusion matrix threshold lab, cohort intelligence heatmaps, an institutional capacity planner, and an offline covariate drift monitor.

---

## 🚀 Quickstart & Verification (Clean Windows Environment)

```powershell
# 1. Run full automated test suite (51 unit, integration & AppTest tests)
python -m pytest -q

# 2. Run headless Streamlit AppTest smoke harness
python -m scripts.smoke_app

# 3. Test external evaluation & covariate drift monitor on bundled independent cohort
python -m src.external_eval --cohort data/independent_cohort.csv
python -m src.monitor --reference data/students.csv --candidate data/independent_cohort.csv

# 4. Launch the interactive dashboard
python -m streamlit run app.py
```

Open `http://localhost:8501` in your browser. Pre-trained and hash-verified artifacts (`artifacts/`) and pre-seeded SQLite advisor accounts are included out-of-the-box.

---

## 🔑 Advisor CRM Demo Credentials

The Support Review workflow uses salted PBKDF2-SHA256 password hashing (310,000 rounds):
- **Lead Advisor / Administrator:** `admin` / Password: `AdminPass12345!`
- **Academic Advisor:** `advisor1` / Password: `AdvisorPass12345!`

---

## 🌟 EduPulse v10.0 Core Modules & Capabilities

1. **Executive Retention Dashboard:** Responsive KPI cards with zero truncation, historical outcome distributions, academic performance boxplots, and empirical insight takeaways.
2. **Student Risk Intelligence:** Live multi-class inference on preloaded demonstration archetypes or custom profiles, distinguishing observed evidence from model probabilities.
3. **Student Digital Twin & What-If Studio:** Interactively simulate changes to student characteristics (approved credits, GPA, tuition payments, debt clearance) with real-time model recalculation, probability shifts, realistic range validation, session scenario history, and non-causal disclosures.
4. **Model Performance Lab & Dynamic Threshold Lab:** 8-algorithm benchmark table with human-readable architecture descriptions, One-vs-Rest ROC curves (AUC 0.898), Precision-Recall curves, Sigmoid reliability diagram, and a dynamic holdout threshold simulator with a live 2x2 binary confusion matrix.
5. **Explainable AI (XAI) Visual Intelligence Center:** Permutation importance, sampled global SHAP, local SHAP Shapley horizontal divergence bar charts, and local LIME surrogate rules.
6. **Intervention Planning & Advisor CRM:** Role-based case review workflow backed by SQLite with tamper-evident audit logs and contact scheduling.
7. **Student Cohort Intelligence & Risk Heatmap:** Interactive heatmaps slicing cohorts by credit completion ratio, 1st-semester grade bands, tuition standing, and scholarship support, with small sample size flags ($N < 30$).
8. **Institutional Analytics & Caseload Capacity:** Realistic advisor capacity modeling, threshold caseload allocation, and modeled tuition preservation scenarios.
9. **Model Reliability Center & Data Drift Monitor:** SHA-256 artifact checksum verification, schema validation, latency benchmarking (~1.2 ms/row), and Population Stability Index (PSI) drift calculation against the independent cohort.
10. **One-Click Publication-Grade PDF & Markdown Dossier Export:** Instant download of formal student retention dossiers in both binary PDF (`.pdf` via ReportLab) and markdown (`.md`).
11. **Nine-Stage Guided Faculty Demo Mode:** Polished viva presentation mode with a Pre-Demo System Readiness Health Check, stage progress bar, and Next/Previous/Restart controls.

---

## 🧪 Automated Testing & Verification

- **51 Automated Tests:** 100% pass rate across ML pipelines, model compatibility, cross-version SimpleImputer patching, student index 130 regression, safety boundaries, role authorization, and headless UI navigation.
- **Headless AppTest Integration:** Verified with `scripts/smoke_app.py` and `tests/test_ui_apptest.py` with zero unhandled exceptions.
- **Zero Temporal Leakage:** Strict stage partitioning (`After semester 1`) strips all future-semester predictors programmatically.


Batch CSV must contain exactly the model feature columns. Export feature-only public examples for a demo with:

```powershell
.\.venv\Scripts\python.exe -c "from src.ml import load_data,stage_features; stage_features(load_data().head(20),'After semester 1').to_csv('demo_batch.csv',index=False)"
```

Unknown columns, nonnumeric codes, infinities and wholly empty rows are rejected. Missing individual cells use fitted imputers. Upload safeguards do not establish anonymity; only use public demo records. Dashboard analysis is open to local users, while case workflows require login.

## Reproducibility and evidence

See docs/FINAL_AUDIT.md, evidence/metrics.json, evidence/model_comparison.csv and execution logs. Full benchmark command above reproduces the release experiment with seed 42. requirements-lock.txt records the tested direct dependencies. requirements.txt retains compatible ranges. No claim of improvement over a measured V8 model is made: V8 baseline verification comprised its 27 tests.

```powershell
.\.venv\Scripts\python.exe -m scripts.audit_explanations
.\.venv\Scripts\python.exe -m src.monitor --reference data/students.csv --candidate approved_features.csv --output drift_report.json
.\.venv\Scripts\python.exe -m src.external_eval --cohort independent_cohort.csv --output external_validation.json
```

Only a genuinely independent cohort establishes external validation. Reusing UCI records is insufficient.

## Deployment boundary

Dockerfile, health check and GitHub Actions are included. Docker and remote CI were not executed here. Docker trains public data at build time; expect a slow build. Run `docker build -t retention-demo .` then `docker run --rm -p 127.0.0.1:8501:8501 retention-demo` if Docker is available. Follow-up data require a mounted local_demo volume to survive container replacement. Do not expose this demonstration publicly with private records.

## Documentation

- docs/ARCHITECTURE.md: components and trust boundaries
- docs/DATASET_AND_SECURITY.md: dataset, timing, privacy and production gaps
- docs/FINAL_AUDIT.md: measured results and limitations
- docs/INTERVIEW.md: resume wording, demonstration and interview answers
- docs/PRESENTATION.html: final presentation, open in a browser and use arrow keys
- Historical V4–V8 reports and the original presentation remain for provenance; their numbers and feature descriptions are superseded by the final audit.

Source: https://archive.ics.uci.edu/dataset/697/predict+students+dropout+and+academic+success
